var imgs = document.querySelector('.imgs');
var slides = ['imgs\\FotoEquipe.png', 'imgs\\foto2.png', 'imgs\\foto3.png'];
var start = 0;


function slider() {
  var currentImage = imgs.querySelector("img");
  if (!currentImage) {
    currentImage = document.createElement("img");
    currentImage.src = slides[start];
    currentImage.style.opacity = 1;
    currentImage.style.position = "absolute";
    imgs.appendChild(currentImage);
  }

  var imgElement = document.createElement("img");
  imgElement.src = slides[start];
  imgElement.style.opacity = 0;
  imgElement.style.position = "absolute"; 

  imgs.appendChild(imgElement);

  setTimeout(function () {
    imgElement.style.opacity = 1;
  }, 10);

  currentImage.style.opacity = 0;
  

  setTimeout(function () {
    imgs.removeChild(currentImage);
  }, 500); 

  if (start < slides.length - 1) {
    start = start + 1;
  } else {
    start = 0;
  }
}
slider();
setInterval(slider, 5000);

function scrollToSection(sectionId) {
    var section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ behavior: "smooth" });
    }
}

document.querySelectorAll('header nav ul li a').forEach(link => {
    link.addEventListener('click', function (event) {
        event.preventDefault();
        var targetSectionId = link.getAttribute('href').slice(1);
        scrollToSection(targetSectionId);
    });
});

function handleScroll() {
    var header = document.querySelector('header');
    var headerHeight = header.offsetHeight;
    var scrollY = window.scrollY;

    if (scrollY > headerHeight) {
        header.classList.add('sticky');
    } else {
        header.classList.remove('sticky');
    }
}

window.addEventListener('load', handleScroll);
window.addEventListener('scroll', handleScroll);

const wrapp = document.querySelector(".wrapp");
const carousel = document.querySelector(".carousel");
const firstCardWidth = carousel.querySelector(".card").offsetWidth;
const arrowBtns = document.querySelectorAll(".wrapp i");
const carouselChildrens = [...carousel.children];
let isDragging = false, isAutoPlay = true, startX, startScrollLeft, timeoutId;
let cardPerView = Math.round(carousel.offsetWidth / firstCardWidth);

carouselChildrens.slice(-cardPerView).reverse().forEach(card => {
    carousel.insertAdjacentHTML("afterbegin", card.outerHTML);
});

carouselChildrens.slice(0, cardPerView).forEach(card => {
    carousel.insertAdjacentHTML("beforeend", card.outerHTML);
});

carousel.classList.add("no-transition");
carousel.scrollLeft = carousel.offsetWidth;
carousel.classList.remove("no-transition");

arrowBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        carousel.scrollLeft += btn.id == "left" ? -firstCardWidth : firstCardWidth;
    });
});
const dragStart = (e) => {
    isDragging = true;
    carousel.classList.add("dragging");

    startX = e.pageX;
    startScrollLeft = carousel.scrollLeft;
}
const dragging = (e) => {
    if(!isDragging) return; 
    carousel.scrollLeft = startScrollLeft - (e.pageX - startX);
}
const dragStop = () => {
    isDragging = false;
    carousel.classList.remove("dragging");
}
const infiniteScroll = () => {
    if(carousel.scrollLeft === 0) {
        carousel.classList.add("no-transition");
        carousel.scrollLeft = carousel.scrollWidth - (2 * carousel.offsetWidth);
        carousel.classList.remove("no-transition");
    }
    // If the carousel is at the end, scroll to the beginning
    else if(Math.ceil(carousel.scrollLeft) === carousel.scrollWidth - carousel.offsetWidth) {
        carousel.classList.add("no-transition");
        carousel.scrollLeft = carousel.offsetWidth;
        carousel.classList.remove("no-transition");
    }
    clearTimeout(timeoutId);
    if(!wrapp.matches(":hover")) autoPlay();
}
const autoPlay = () => {
    if(window.innerWidth < 800 || !isAutoPlay) return;
    timeoutId = setTimeout(() => carousel.scrollLeft += firstCardWidth, 2500);
}
autoPlay();
carousel.addEventListener("mousedown", dragStart);
carousel.addEventListener("mousemove", dragging);
document.addEventListener("mouseup", dragStop);
carousel.addEventListener("scroll", infiniteScroll);
wrapp.addEventListener("mouseenter", () => clearTimeout(timeoutId));
wrapp.addEventListener("mouseleave", autoPlay);

function toggleCartaoContent(header) {
    const content = header.nextElementSibling;
    const arrow = header.querySelector('.arrow');
    
    content.style.maxHeight = content.style.maxHeight ? null : content.scrollHeight + 'px';
    header.classList.toggle('expanded');
    arrow.style.transform = arrow.style.transform === 'rotateX(180deg)' ? 'rotate(0)' : 'rotateX(180deg)';
}


const elH = document.querySelectorAll(".timeline li > div");

window.addEventListener("load", init);

function init() {
  setEqualHeights(elH);
}

function setEqualHeights(el) {
  let counter = 0;
  for (let i = 0; i < el.length; i++) {
    const singleHeight = el[i].offsetHeight;

    if (counter < singleHeight) {
      counter = singleHeight;
    }
  }

  for (let i = 0; i < el.length; i++) {
    el[i].style.height = `${counter}px`;
  }
}


function openModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.style.display = 'block';
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.style.display = 'none';
}

const modalButtons = document.querySelectorAll('.open-modal-btn');
modalButtons.forEach(button => {
    button.addEventListener('click', () => { 
        const modalId = button.getAttribute('data-modal-target');
        openModal(modalId);
    });
});

const closeButtons = document.querySelectorAll('.close-modal-btn');
closeButtons.forEach(button => {
    button.addEventListener('click', () => {
        const modalId = button.getAttribute('data-modal-target');
        closeModal(modalId);
    });
});

window.addEventListener('click', (event) => {
    if (event.target.classList.contains('modal')) {
        const modalId = event.target.id;
        closeModal(modalId);
    }
});

var viewMode = getCookie("view-mode");
if(viewMode == "desktop"){
    viewport.setAttribute('content', 'width=1024');
}else if (viewMode == "mobile"){
    viewport.setAttribute('content', 'width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no');
}